/**
 * Source code from the Java Parallel Programming Coursera course.
 */
package co.edu.unal.paralela;
